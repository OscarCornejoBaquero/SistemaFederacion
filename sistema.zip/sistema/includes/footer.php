<footer class="bg-black text-center text-lg-start formato_footer">
  <!-- Copyright -->
  <div class="text-center p-3 estilo_footer" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2021 Copyright: Universidad de Guayaquil - FCMF - Ing. Software - Contrucción de Software - Grupo #2 
  </div>
  <!-- Copyright -->
</footer>